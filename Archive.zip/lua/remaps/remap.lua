vim.g.mapleader = " "
vim.keymap.set("n", "<leader>x", vim.cmd.Ex)

