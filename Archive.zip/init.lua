require("config.lazy")
require("remaps")
